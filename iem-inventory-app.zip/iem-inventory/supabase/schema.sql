-- ============================================================
-- IEM Workshop Inventory — Supabase schema
-- Run this once in: Supabase Dashboard > SQL Editor > New query
-- ============================================================

-- 1) Profiles: one row per login, holds the role.
-- role: 'admin' (หัวหน้าช่าง/หัวหน้าสต๊อก — full control)
--       'staff' (ทีมผลิต — can view stock, produce, cannot edit catalog)
--       'purchasing' (ฝ่ายจัดซื้อ — can view stock + restock, cannot produce/edit catalog)
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'staff' check (role in ('admin','staff','purchasing')),
  created_at timestamptz not null default now()
);

-- Auto-create a profile row (default role 'staff') whenever a new login is created.
-- You (admin) create the login itself in Authentication > Users, then promote the
-- role afterwards in Table Editor > profiles, or from the in-app Admin panel.
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.email), 'staff');
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();

-- Helper used inside RLS policies (SECURITY DEFINER avoids recursive-RLS issues).
create or replace function is_admin()
returns boolean as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin');
$$ language sql security definer stable;

-- 2) Materials — the shared raw-material stock.
create table if not exists materials (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  unit text not null default 'pcs',
  qty numeric not null default 0,
  created_at timestamptz not null default now()
);

-- 3) Models — product line items (CIEM/Tactical/Lifestyle/Sleeplug/ซ่อม), each with a BOM.
create table if not exists models (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  created_at timestamptz not null default now()
);

create table if not exists model_bom (
  id uuid primary key default gen_random_uuid(),
  model_id uuid not null references models(id) on delete cascade,
  material_id uuid not null references materials(id) on delete cascade,
  qty numeric not null default 1
);

-- 4) Transactions — one row per "กดผลิต" (production order). bom_snapshot freezes the
-- recipe used at that moment, so edits to a model's BOM later don't break old records
-- or cancellations.
create table if not exists transactions (
  id uuid primary key default gen_random_uuid(),
  model_id uuid references models(id),
  model_name text not null,
  category text not null,
  order_ref text not null,
  staff_name text not null,
  bom_snapshot jsonb not null, -- [{material_id, material_name, unit, qty}, ...]
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

-- 5) Stock log — full in/out ledger for accounting reconciliation.
create table if not exists stock_log (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('in','out')),
  material_id uuid references materials(id),
  material_name text not null,
  unit text not null default '',
  amount numeric not null,
  order_ref text not null default '',
  staff_name text not null default '',
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

-- 6) App settings — small key/value store (currently just the Google Sheets webhook URL).
create table if not exists app_settings (
  key text primary key,
  value text not null default ''
);

-- ============================================================
-- Row Level Security
-- ============================================================
alter table profiles enable row level security;
alter table materials enable row level security;
alter table models enable row level security;
alter table model_bom enable row level security;
alter table transactions enable row level security;
alter table stock_log enable row level security;

-- profiles: everyone signed in can read all profiles (needed to show staff names);
-- only admins can change roles.
create policy "profiles_select_all" on profiles for select using (auth.role() = 'authenticated');
create policy "profiles_update_admin" on profiles for update using (is_admin());

-- materials: everyone reads; only admin adds/removes; qty updates (produce/restock)
-- allowed for any signed-in user since staff/purchasing both need to move stock.
create policy "materials_select" on materials for select using (auth.role() = 'authenticated');
create policy "materials_insert_admin" on materials for insert with check (is_admin());
create policy "materials_update_any" on materials for update using (auth.role() = 'authenticated');
create policy "materials_delete_admin" on materials for delete using (is_admin());

-- models & BOM: everyone reads; only admin creates/edits/deletes (matches "หัวหน้าช่าง
-- แก้ไขรุ่น/สูตรเท่านั้น" from the spec).
create policy "models_select" on models for select using (auth.role() = 'authenticated');
create policy "models_write_admin" on models for insert with check (is_admin());
create policy "models_update_admin" on models for update using (is_admin());
create policy "models_delete_admin" on models for delete using (is_admin());

create policy "bom_select" on model_bom for select using (auth.role() = 'authenticated');
create policy "bom_write_admin" on model_bom for insert with check (is_admin());
create policy "bom_update_admin" on model_bom for update using (is_admin());
create policy "bom_delete_admin" on model_bom for delete using (is_admin());

-- transactions: everyone reads (needed for the shortage/history checks), any signed-in
-- user can insert (กดผลิต), but only admin can delete (ยกเลิกออเดอร์ — matches
-- "รายงานเห็นเฉพาะหัวหน้าช่าง").
create policy "tx_select" on transactions for select using (auth.role() = 'authenticated');
create policy "tx_insert_any" on transactions for insert with check (auth.role() = 'authenticated');
create policy "tx_delete_admin" on transactions for delete using (is_admin());

-- stock_log: insert allowed for any signed-in user (produce/restock both log here);
-- select restricted to admin only (the accounting-facing ledger view is admin-only).
create policy "log_insert_any" on stock_log for insert with check (auth.role() = 'authenticated');
create policy "log_select_admin" on stock_log for select using (is_admin());

alter table app_settings enable row level security;
create policy "settings_select" on app_settings for select using (auth.role() = 'authenticated');
create policy "settings_write_admin" on app_settings for insert with check (is_admin());
create policy "settings_update_admin" on app_settings for update using (is_admin());

-- ============================================================
-- Seed data (optional) — comment out if you'd rather start empty
-- ============================================================
-- insert into materials (name, unit, qty) values
--   ('ear impression silicone(new set)(800g*2)', 'set', 30),
--   ('KZ Case_pcs', 'pcs', 1);
