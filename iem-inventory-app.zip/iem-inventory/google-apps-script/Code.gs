/**
 * IEM Workshop — Google Sheets receiver.
 *
 * SETUP:
 * 1. Create (or open) the Google Sheet you want reports sent to.
 * 2. In the Sheet: Extensions > Apps Script.
 * 3. Delete the placeholder code and paste this whole file in.
 * 4. Click Deploy > New deployment > select type "Web app".
 *      - Execute as: Me
 *      - Who has access: Anyone
 *    Click Deploy, authorize when prompted, then copy the "Web app URL".
 * 5. Paste that URL into the app's Settings page (หัวหน้าช่าง > ตั้งค่า)
 *    as the "Google Sheets Webhook URL".
 *
 * That's it — the "ส่งเข้า Google Sheet" buttons in the Stock and Report
 * pages will now append rows into a tab matching the report name
 * (StockLog / ProductionReport), creating the tab if it doesn't exist yet.
 */
function doPost(e) {
  const body = JSON.parse(e.postData.contents);
  const sheetName = body.sheetName || 'Report';
  const rows = body.rows || [];

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) sheet = ss.insertSheet(sheetName);

  if (rows.length === 0) {
    return ContentService.createTextOutput(JSON.stringify({ ok: true, added: 0 }))
      .setMimeType(ContentService.MimeType.JSON);
  }

  // Write headers if the sheet is empty
  if (sheet.getLastRow() === 0) {
    const headers = Object.keys(rows[0]);
    sheet.appendRow(headers);
  }

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const values = rows.map(r => headers.map(h => r[h] ?? ''));
  sheet.getRange(sheet.getLastRow() + 1, 1, values.length, headers.length).setValues(values);

  return ContentService.createTextOutput(JSON.stringify({ ok: true, added: values.length }))
    .setMimeType(ContentService.MimeType.JSON);
}
